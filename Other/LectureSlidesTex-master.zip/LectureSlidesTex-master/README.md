# LectureSlidesTex
