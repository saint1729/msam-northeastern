# Data Sets

### Datasets

| Dataset   | Title          | Lab |
| :---         |     :---:      |          ---: |
| Ames Housing Prices  | Ames | Lab 1 |
| NYC AirBnB Prices  | NYCAirBnB | Lab 1 |
| Gendered Voice | GenderedVoice | Lab 3 |
