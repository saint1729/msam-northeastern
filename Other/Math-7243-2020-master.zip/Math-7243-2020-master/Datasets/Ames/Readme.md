# Ames Housing Dataset 

Mirror of the dataset stored at Kaggle as of 1/14/2020
https://www.kaggle.com/c/house-prices-advanced-regression-techniques/
