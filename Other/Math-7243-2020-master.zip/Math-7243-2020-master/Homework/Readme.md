# Homeworks

* [Homework 1](https://github.com/tipthederiver/Math-7243-2020/raw/master/Homework/Homework%201.pdf): Matrix Calculus, Loss Functions, and Linear Regression
* [Homework 2](https://github.com/tipthederiver/Math-7243-2020/raw/master/Homework/Homework%202.pdf): LDA, Cubic Splines, and Gradiant Decent.
