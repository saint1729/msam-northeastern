function [] = plot_decisiontree_figure_bagg (X0, X1, t)

mn = -3;
mx = 3;

% grid
grid = mn : 0.1 : mx;

% grid length
gl = length(grid);

% construct the two dimensional grid (input matrix X = [I J])
I = reshape(repmat(grid, gl, 1), gl * gl, 1);
J = repmat(grid', gl, 1);

% predictions
p = zeros(gl, gl);
for b = 1 : length(t)
    %p = p + reshape(treeval(t{b}, [I J])', gl, gl);
    %mileage4K = predict(tree,[4000 4; 4000 6; 4000 8])
    p = p + reshape(predict(t{b}, [I J])', gl, gl);
end
p = p ./ length(t);

%mesh(mn : 0.1 : mx, mn : 0.1 : mx, p);
surf(mn : 0.1 : mx, mn : 0.1 : mx, p);
shading interp
axis([mn mx mn mx 0 1]);
xlabel('x_1');
ylabel('x_2');
zlabel('P(y|x)');

return

% u = 1;
% for i = mn : 0.1 : mx
%     J = mn : 0.1 : mx;
%     p(u, :) = zeros(1, length(J));
%     for b = 1 : length(t)
%         p(u, :) = p(u, :) + treeval(t{b}, [i * ones(length(J), 1) J'])';
%     end
%     p(u, :) = p(u, :) / length(t);
%     
%     u = u + 1
% end
