clear 
clc

n0 = 100;   % number of negatives
n1 = 100;   % number of positives
errPos = 0.05; % percentage of mislabeled positives
errNeg = 0.10; % percentage of mislabeled negatives
method = 2;            % parameter of data generator
boxEdgeHalfLength = 2; % parameter of data generator

% reseed the random number generator
randn('state', 1234)

% neural network parameters
h = 8;   % hidden neurons
B = 100;  % number of bagged models

% createdata set
[X, y] = ballinbox(2, n1, n0, errPos, errNeg, method, boxEdgeHalfLength);

% generate n0 negatives and n1 positives, so we can plot the figure
X0 = X(y == 0, :);
X1 = X(y == 1, :);

plot(X0(:, 1), X0(:, 2), 'bo', X1(:, 1), X1(:, 2), 'r+');
axis([(min(X(:, 1)) - 0.5) (max(X(:, 1)) + 0.5) (min(X(:, 2)) - 0.5) (max(X(:, 2)) + 0.5)]);
xlabel('x_1');
ylabel('x_2');
pause

%axis([-3 3 -3 3]);
%figure

for b = 1 : B
    b 
    
    % sample with replacement
    q = ceil(rand(1, size(X, 1)) * size(X, 1));
    
    % form a bootstrapped training set
    Xb = X(q, :);
    yb = y(q, 1);
    
    % initialize and train b-th neural network
    net{b} = newff(Xb', yb', h, {'tansig', 'tansig'}, 'trainrp');
    net{b}.trainParam.epochs = 1000;
    net{b}.trainParam.show = NaN;
    net{b}.trainParam.showWindow = true;
    net{b}.trainParam.max_fail = 10;
    net{b}.trainParam.min_grad = 1e-300;
    net{b}.divideFcn = 'divideind';
    net{b}.divideParam.trainInd = 1 : size(Xb, 1);
    net{b}.divideParam.valInd = [];
    net{b}.divideParam.testInd = [];
    net{b} = train(net{b}, Xb', yb');
end

figure
% plot posterior probabilities
plot_neuralnet_figure_bagg(X0, X1, net);
