clear 
clc

n0 = 100;   % number of negatives
n1 = 100;   % number of positives
errPos = 0.05; % percentage of mislabeled positives
errNeg = 0.1; % percentage of mislabeled negatives
method = 2;            % parameter of data generator
boxEdgeHalfLength = 2; % parameter of data generator

% reseed the random number generator
randn('state', 1234)

% neural network parameters
h = 8; % hidden neurons

% create data set
[X, y] = ballinbox(2, n1, n0, errPos, errNeg, method, boxEdgeHalfLength);

% generate n0 negatives and n1 positives (should be done better)
X0 = X(find(y == 0), :);
X1 = X(find(y == 1), :);

plot(X0(:, 1), X0(:, 2), 'bo', X1(:, 1), X1(:, 2), 'r+');
axis([(min(X(:, 1)) - 0.5) (max(X(:, 1)) + 0.5) (min(X(:, 2)) - 0.5) (max(X(:, 2)) + 0.5)]);
xlabel('x_1');
ylabel('x_2');
pause

%axis([-3 3 -3 3]);
%figure

% create neural network
net = newff(X', y', h, {'tansig', 'tansig'}, 'trainrp');

% set some training parameters and data sets
net.trainParam.epochs = 100;
net.trainParam.show = NaN;
net.trainParam.showWindow = false;
net.trainParam.max_fail = 10;
net.divideFcn = 'divideind';
net.divideParam.trainInd = 1 : size(X, 1);
net.divideParam.valInd = [];
net.divideParam.testInd = [];

% train network
net = train(net, X', y');

% plot posterior probabilities
plot_neuralnet_figure(X0, X1, net);

