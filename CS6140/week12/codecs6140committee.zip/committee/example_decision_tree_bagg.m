clear 
clc

n0 = 100;   % number of negatives
n1 = 100;   % number of positives
errPos = 0.05; % percentage of mislabeled positives
errNeg = 0.10; % percentage of mislabeled negatives
method = 2;            % parameter of data generator
boxEdgeHalfLength = 2; % parameter of data generator

% reseed the random number generator
randn('state', 1234)

% neural network parameters
B = 1000; % use B trees

% create data set
[X, y] = ballinbox(2, n1, n0, errPos, errNeg, method, boxEdgeHalfLength);

% generate n0 negatives and n1 positives, so we can plot the figure
X0 = X(y == 0, :);
X1 = X(y == 1, :);


% X = rand(200, 2);
% for i = 1 : 200
%     if X(i, 1) < 0.5 && X (i, 2) < 0.5
%         y(i) = 1;
%     else
%         y(i) = 0;
%     end
% end
% X0 = X(find(y == 0), :);
% X1 = X(find(y == 1), :);


plot(X0(:, 1), X0(:, 2), 'bo', X1(:, 1), X1(:, 2), 'r+');
axis([(min(X(:, 1)) - 0.5) (max(X(:, 1)) + 0.5) (min(X(:, 2)) - 0.5) (max(X(:, 2)) + 0.5)]);
xlabel('x_1');
ylabel('x_2');
pause


for b = 1 : B
    b 
    
    % sample with replacement
    q = ceil(rand(1, size(X, 1)) * size(X, 1));
    
    % form a bootstrapped training set
    Xb = X(q, :);
    yb = y(q, 1);

    % train b-th decision tree    
    %t{b} = treefit(Xb, yb, 'splitmin', 1);
    t{b} = fitrtree(Xb, yb);
end

figure
% plot posterior probabilities
plot_decisiontree_figure_bagg(X0, X1, t);
