clear 
clc

n0 = 100;   % number of negatives
n1 = 100;   % number of positives
errPos = 0.05; % percentage of mislabeled positives
errNeg = 0.1; % percentage of mislabeled negatives
method = 2;            % parameter of data generator
boxEdgeHalfLength = 2; % parameter of data generator

% reseed the random number generator
randn('state', 1234)


% create data set
[X, y] = ballinbox(2, n1, n0, errPos, errNeg, method, boxEdgeHalfLength);

% generate n0 negatives and n1 positives (should be done better)
X0 = X(find(y == 0), :);
X1 = X(find(y == 1), :);

plot(X0(:, 1), X0(:, 2), 'bo', X1(:, 1), X1(:, 2), 'r+');
axis([(min(X(:, 1)) - 0.5) (max(X(:, 1)) + 0.5) (min(X(:, 2)) - 0.5) (max(X(:, 2)) + 0.5)]);
xlabel('x_1');
ylabel('x_2');
pause

%axis([-3 3 -3 3]);
%figure

t{1} = fitrtree(X, y);

figure
% plot posterior probabilities
plot_decisiontree_figure_bagg(X0, X1, t);
