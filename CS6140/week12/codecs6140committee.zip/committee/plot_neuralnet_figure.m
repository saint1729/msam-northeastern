function [] = plot_neuralnet_figure (X0, X1, net)

mn = -3;
mx = 3;

u = 1;
for i = mn : 0.1 : mx
    v = 1;
    for j = mn : 0.1 : mx
        p(u, v) = sim(net, [i j]')';
        v = v + 1;
	end
    u = u + 1;
end

%mesh(mn : 0.1 : mx, mn : 0.1 : mx, p);
surf(mn : 0.1 : mx, mn : 0.1 : mx, p);
shading interp
axis([mn mx mn mx 0 1]);
xlabel('x_1');
ylabel('x_2');
zlabel('P(y|x)');

return