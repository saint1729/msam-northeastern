Function to run is:

em.m

The script em.m was developed to illustrate the performance of three algorithms for clustering and parameter estimation with 2-D Gaussian mixtures: (1) the K-means clustering, (2) the Classification Expectation-Maximization, and (3) the Expectation-Maximization. 

====================
Predrag Radivojac
Northeastern University
Boston, Massachusetts

Last update: January 2021
====================