A = [[1, 0, 0]; [1, 1, 0]; [1, 1, 1]; [0, 1, 1]; [0, 0, 1]];
disp(OBasis(A));
disp(NBasis(A));
disp(projection([2, 2, -1, 1, 1], A));
